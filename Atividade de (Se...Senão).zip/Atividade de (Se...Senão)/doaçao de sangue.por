programa {
  funcao inicio() {
    inteiro idade

    escreva("digite sua idade")
    leia (idade)

    se(idade>=18 e idade<=67)
    {
      escreva("voce esta apito a doar sangue")
    }
    senao
    {
      escreva("voce nao esta apito a doar sangue")
    }

    
  }
}
