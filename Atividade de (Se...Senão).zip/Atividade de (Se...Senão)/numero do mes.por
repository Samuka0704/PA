programa {
  funcao inicio() {
    inteiro mes

    escreva("digite o numero do mes (1 a 12): ")
    leia(mes)
    
    se(mes==1)
    {
     escreva("janeiro - 31 dias")
    }
      senao se (mes==2)
      {
      escreva("fevereiro - 28 dias")
      }
      senao se (mes==3)
      {
      escreva("março - 31 dias")
      }
      senao se (mes==4)
      {
      escreva("abril - 30 dias")
      }
      senao se (mes==5)
      {
      escreva("maio - 31 dias")
      }
      senao se (mes==6)
      {
      escreva("junho - 30 dias")
      }
      senao se (mes==7)
      {
      escreva("julho - 31 dias")   
      }
       senao se (mes==8)
      {
      escreva("agosto - 31 dias")
      }
      senao se (mes==9)
      {
      escreva("setembro - 30 dias")
      }
      senao se (mes==10)
      {
      escreva("outubro - 31 dias")
      }
      senao se (mes==11)
      {
      escreva("novembro - 30 dias")
      }
      senao se (mes==12)
      {
      escreva("dezembro - 31 dias")
      }
      senao
      {
        escreva("mes invalido")
      }
    }
  }

