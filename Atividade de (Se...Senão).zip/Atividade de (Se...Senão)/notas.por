programa {
  funcao inicio() {
    caracter nome
   real nota1, nota2, nota3, nota4, media

   escreva("Digite seu nome: ")
   leia(nome)

   escreva("Digite a primeira nota: ")
   leia(nota1)

   escreva("Digite a segunda nota: ")
   leia(nota2)

   escreva("Digite a terceira nota: ")
   leia(nota3)

   escreva("Digite a quarta nota: ")
   leia(nota4)

   media = (nota1 + nota2 + nota3 + nota4) / 4

   escreva("aluno: ", nome)
   escreva("Média final: ", media)

   se (media >= 6)
      escreva("voce foi aprovado")
   senao
      escreva("voce foi reprovado")
   
    
  }
}
