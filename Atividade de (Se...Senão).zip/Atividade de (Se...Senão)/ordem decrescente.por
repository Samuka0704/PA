programa {
  funcao inicio() {
    inteiro n1, n2, n3, aux
    escreva("Digite o primeiro número: ")
   leia(n1)

   escreva("Digite o segundo número: ")
   leia(n2)

   escreva("Digite o terceiro número: ")
   leia(n3)

   // Troca entre n1 e n2
   se (n1 < n2) 
   {
      aux = n1
      n1 = n2
      n2 = aux
   }

   // Troca entre n1 e n3
   se (n1 < n3) 
   {
      aux = n1
      n1 = n3
      n3 = aux
   }
   

   // Troca entre n2 e n3
   se (n2 < n3) 
   {
      aux = n2
      n2 = n3
      n3 = aux
   }
  

   escreva("Números em ordem decrescente: ", n1," ",n2," ",n3)
  

    
  }
}
